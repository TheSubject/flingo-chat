<!-- 
Version 1.0 [15-11-2019]

--Initial release

-->



<!-- 
UPDATE 1.1 [06-01-2020]

--Added custom background support
--Added search support for chats, calls and contacts
--Added Theme Modal
--Added Goup member action in groups info
--Improve Dark Mode
--Minor adjustment & Some Bug Fixes

 -->


<!-- 
UPDATE 1.2 [19-02-2020]

--Added 3 Login pages
--Added 3 Signup pages
--Added 1 Forgot password page
--Added 1 account verify page
--Fixed chat bubble dropdown issue

 -->