You can find documentation here
http://www.cetaceanstechlab.com/theme/flint/documentation.html