var gulp = require("gulp"),
    sass = require("gulp-sass"),
    postcss = require("gulp-postcss"),
    autoprefixer = require("autoprefixer"),
    cssnano = require("cssnano"),
    sourcemaps = require("gulp-sourcemaps"),
    browserSync = require('browser-sync').create();

var paths = {
    styles: {
        src: "app/scss/**/*.scss",
        dest: "app/css"
    }

};


function style() {
    return gulp
        .src('app/scss/**/*.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .on("error", sass.logError)
        .pipe(postcss([autoprefixer(), cssnano()]))
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('app/css'))
        .pipe(browserSync.stream());
}


function watch() {
    browserSync.init({
        server: {
            baseDir: "./app",
            injectChanges: true
        }
    });
    gulp.watch(paths.styles.src, style);
    gulp.watch("app/*.html").on('change', browserSync.reload);
}
 

exports.watch = watch
exports.style = style;

var build = gulp.parallel(style, watch);
gulp.task('default', build);